

## Installation

1. Clone it.
You need to clone (download) it to your local machine.

```bash
  git clone repo_url
```
    
3. Install NPM packages

```bash
  npm install
```
4. Run Face Web using nodemon

```bash
  npm start
```
5. Run Face Web on Browser

```bash
  localhost:3000

To move to dashboard page
enter these cred
username:- test
password:- test123@