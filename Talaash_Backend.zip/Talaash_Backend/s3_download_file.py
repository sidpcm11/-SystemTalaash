import boto3
import os

s3 = boto3.client("s3")

global source
source = "C:/Users/sidpc/Pictures/Project_Images/source.jpg"

while True :
    try :
        metadata = s3.head_object(Bucket='sih-project-vss', Key="source.jpg")
        c_time = metadata["LastModified"]
        s3.download_file(
            Bucket="sih-project-vss",
            Key="source.jpg",
            # Filename="C:/Users/sidpc/Pictures/Project_Images/source.jpg"
            Filename=source
        )
        s3.delete_object(
            Bucket='sih-project-vss',
            Key='source.jpg'
        )
        print(c_time)
        os.system('python main.py')
        break

    except :
        print("Image not uploaded yet")
