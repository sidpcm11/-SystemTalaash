import datetime
import cv2
import boto3
# import time
import compare_faces as cf
import publish as pb
import emotion
import object_detection
# import s3_download_file

global dt
dt = datetime.datetime.now()

def main():

    cam = cv2.VideoCapture(1)
    wCam, hCam = 1280, 720
    cam.set(3, wCam)
    cam.set(4, hCam)

    global num
    num=1
    flag=0

    while True:
        success, frame = cam.read()
        dt = datetime.datetime.now()
        
        frame = cv2.putText(frame, dt.strftime("%d-%m-%Y  %H:%M:%S"),
                            (10, 30),
                            cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.5,
                            (0, 0, 255), 2)

        target = "C:/Users/sidpc/Pictures/Project_Images/target.jpeg"
        cv2.imwrite(target, frame)

        source = "C:/Users/sidpc/Pictures/Project_Images/source.jpg"
        # source = s3_download_file.source

        try :
            face_matches = cf.compare_faces(source, target)
            # expression = emotion.detect_faces(target)
        
            if (face_matches != 0) :
                # object_detection.detect_labels()
                frame_left = wCam * cf.left
                frame_top = hCam * cf.top
                frame_right = frame_left + (wCam * cf.width)
                frame_bottom = frame_top + (hCam * cf.height)

                frame = cv2.rectangle(frame, 
                                        (int(frame_left), int(frame_top)), (int(frame_right), int(frame_bottom)),
                                        (255, 0, 0), 2)
                
                frame = cv2.putText(frame, "Similarity=" + "%.2f" % cf.sim + "%",
                                    (920, 700),
                                    cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.5,
                                    (0, 0, 255), 2)
                
                frame = cv2.putText(frame, "Rajasthan_College_1",
                                    (870, 30),
                                    cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.5,
                                    (255, 0, 0), 2)
                
                # frame = cv2.putText(frame, "Emotion:" + expression,
                #                     (10, 700),
                #                     cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.5,
                #                     (0, 255, 0), 2)

                target = "C:/Users/sidpc/Pictures/Test/{}.jpeg".format(dt.strftime("%d-%m-%Y at %H.%M.%S"))
                cv2.imwrite(target, frame)
                # time.sleep(0.5)

                if(flag==0) :
                    pb.publish()

                s3 = boto3.client("s3")
                s3.upload_file(
                    Filename=target,
                    Bucket="sih-project-vss",
                    # Key="Detected_Images/{}.jpeg".format(dt.strftime("%d-%m-%Y at %H.%M.%S"))
                    # Key="target{}.jpeg".format(num)
                    Key="target.jpeg"
                )
                num = num + 1

            print("Face matches: " + str(face_matches))
            flag=1

        except :
            print("Exception has occured / No face detected yet")

        # cv2.imshow("Image", frame)
        cv2.waitKey(1)


if __name__ == "__main__":
        main()