import boto3

def compare_faces(sourceFile, targetFile):

    global left, top, width, height, sim, face_emotion
    
    client=boto3.client('rekognition')
   
    imageSource=open(sourceFile,'rb')
    imageTarget=open(targetFile,'rb')

    response = client.compare_faces(SimilarityThreshold=30,
                                  SourceImage={'Bytes': imageSource.read()},
                                  TargetImage={'Bytes': imageTarget.read()})
    
    for faceMatch in response['FaceMatches']:
        position = faceMatch['Face']['BoundingBox']
        similarity = str(faceMatch['Similarity'])
        sim = faceMatch['Similarity']
        left = position['Left']
        top = position['Top']
        width = position['Width']
        height = position['Height']

        print('The face at ' +
               str(position['Left']) + ' ' +
               str(position['Top']) +
               ' matches with ' + similarity + '% confidence')
    imageSource.close()
    imageTarget.close()
    return len(response['FaceMatches'])