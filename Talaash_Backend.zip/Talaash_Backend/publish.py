import boto3
import main

def publish() :
    client = boto3.client('sns')

    response = client.publish(
        TopicArn="arn:aws:sns:ap-south-1:639661757204:it-hack",
        Message='!!Alert!!\n\nCriminal Detected on ' + str(main.dt) + "\n\nYou can check the criminal's photo at http://www.talaash.ml/criminalImg\n\n",
        Subject='Talaash System'
    )